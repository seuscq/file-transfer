#ifndef PERM_CONV_H
#define PERM_CONV_H

uint16_t perm_convert(uint32_t bta_perm);

#endif //PERM_CONV_H
