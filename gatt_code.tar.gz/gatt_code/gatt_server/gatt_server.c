#include <stdio.h>
#include "bt_gatt_server.h"
#include "gatt_server_glue.h"

tGattServerCb *gatt_server_cb = NULL;

int bt_gatt_server_init(tGattServerCb *cb)
{
	gatt_server_cb = cb;
	return CSM_init();
}

tGattServerCb *bt_get_gatt_server_cb()
{
	return gatt_server_cb;
}

int bt_gatt_create_server(tGattAddSvc *svc)
{
	return CSM_addService(svc->uuid,svc->primary,svc->number);
}

int bt_gatt_add_characteristic(tGattAddChar *chr)
{
	return CSM_addChar(chr->svc_handle,chr->uuid,chr->properties,
			chr->permissions);
}

int bt_gatt_add_descriptor(tGattAddDesc *desc)
{
	return CSM_addDesc(desc->svc_handle,desc->uuid,desc->permissions);
}

int bt_gatt_start_service(tGattStarSvc *start_svc)
{
	return CSM_startService(start_svc->svc_handle);
}

int bt_gatt_stop_service(tGattStopSvc *stop_svc)
{
	return CSM_stopService(stop_svc->svc_handle);
}

int bt_gatt_delete_service(tGattDelSvc *del_svc)
{
	return CSM_deleteService(del_svc->svc_handle);
}

int bt_gatt_send_read_response(tGattSendReadRsp *pData)
{
	CSM_sendResponse(pData->trans_id,pData->status,pData->svc_handle,
			pData->value,pData->value_len,pData->auth_req);
}

int bt_gatt_send_write_response(tGattWriteRsp *pData)
{
	;
	//TODO
}

int bt_gatt_send_notification(tGattNotifyRsp *pData)
{
	return CSM_sendIndication(pData->svc_handle,pData->fg_confirm,
			pData->value,pData->value_len);
}

int bt_gatt_server_deinit()
{
	return CSM_deinitGatts();
}
