/*
 *  Copyright (C) 2019 Realtek Semiconductor Corporation.
 *
 *  Author: Alex Lu <alex_lu@realsil.com.cn>
 */
#include <stdio.h>
#include <stdint.h>

#define BTA_WAKE_CODE	0x78

#define REQ_PENDING	0
#define REQ_DONE	1
struct bta_command {
	unsigned int id;
	uint16_t opcode;
	uint16_t req_status;
	int req_result;
	int argc;
	void **argv;
	uint32_t rparams[2];
};

typedef int (*bcmd_handler_t)(uint16_t opcode, int argc, void **argv);

void set_bta_cmd_fd(int fd[2]);
void set_bta_mainloop_id(pthread_t tid);
void bta_register_handler(bcmd_handler_t handler);

int bta_submit_command_wait(uint16_t opcode, int argc, void **argv);
void btgatt_run_command(void);

void bta_clear_commands(void);
