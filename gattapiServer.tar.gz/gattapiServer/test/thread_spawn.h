#ifndef SPAWN_H
#define SPAWN_H

void spawn_thread();

#endif //guard
