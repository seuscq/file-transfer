#include <stdint.h>

#include "perm_convert.h"

/*
 * ATT attribute permission bitfield values. Permissions are grouped as
 * "Access", "Encryption", "Authentication", and "Authorization". A bitmask of
 * permissions is a byte that encodes a combination of these.
 */
#define BT_ATT_PERM_READ		0x01
#define BT_ATT_PERM_WRITE		0x02
#define BT_ATT_PERM_READ_ENCRYPT	0x04
#define BT_ATT_PERM_WRITE_ENCRYPT	0x08
#define BT_ATT_PERM_ENCRYPT		(BT_ATT_PERM_READ_ENCRYPT | \
					BT_ATT_PERM_WRITE_ENCRYPT)
#define BT_ATT_PERM_READ_AUTHEN		0x10
#define BT_ATT_PERM_WRITE_AUTHEN	0x20
#define BT_ATT_PERM_AUTHEN		(BT_ATT_PERM_READ_AUTHEN | \
					BT_ATT_PERM_WRITE_AUTHEN)
#define BT_ATT_PERM_AUTHOR		0x40
#define BT_ATT_PERM_NONE		0x80
#define BT_ATT_PERM_READ_SECURE		0x0100
#define BT_ATT_PERM_WRITE_SECURE	0x0200
#define BT_ATT_PERM_SECURE		(BT_ATT_PERM_READ_SECURE | \
					BT_ATT_PERM_WRITE_SECURE)


#define MTK_GATT_PERM_READ              (1 << 0) /* bit 0 */
#define MTK_GATT_PERM_READ_ENCRYPTED    (1 << 1) /* bit 1 */
#define MTK_GATT_PERM_READ_ENC_MITM     (1 << 2) /* bit 2 */
#define MTK_GATT_PERM_WRITE             (1 << 4) /* bit 4 */
#define MTK_GATT_PERM_WRITE_ENCRYPTED   (1 << 5) /* bit 5 */
#define MTK_GATT_PERM_WRITE_ENC_MITM    (1 << 6) /* bit 6 */
#define MTK_GATT_PERM_WRITE_SIGNED      (1 << 7) /* bit 7 */
#define MTK_GATT_PERM_WRITE_SIGNED_MITM (1 << 8) /* bit 8 */

uint16_t perm_convert(uint32_t bta_perm)
{
	uint16_t bluez_perm;

	bluez_perm = 0;

	if(bta_perm & MTK_GATT_PERM_READ)
		bluez_perm |= BT_ATT_PERM_READ;
	if(bta_perm & MTK_GATT_PERM_READ_ENCRYPTED)
		bluez_perm |= BT_ATT_PERM_READ_ENCRYPT;
	if(bta_perm & MTK_GATT_PERM_READ_ENC_MITM)
		bluez_perm |= BT_ATT_PERM_READ_AUTHEN;
	if(bta_perm & MTK_GATT_PERM_WRITE)
		bluez_perm |= BT_ATT_PERM_WRITE;
	if(bta_perm & MTK_GATT_PERM_WRITE_ENCRYPTED)
		bluez_perm |= BT_ATT_PERM_READ_ENCRYPT;
	if(bta_perm & MTK_GATT_PERM_WRITE_ENCRYPTED)
		bluez_perm |= BT_ATT_PERM_WRITE_AUTHEN;
	if(bta_perm & MTK_GATT_PERM_WRITE_SIGNED)
		;// ignore
	if(bta_perm & MTK_GATT_PERM_WRITE_SIGNED_MITM)
		;// ignore

	return bluez_perm;
}
