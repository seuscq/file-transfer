#ifndef GATT_API_H
#define GATT_API_H

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

#define AG_GATT_MAX_ATTR_LEN 600
#define AG_GATT_MAX_UUID_LEN 37
#define AG_MAX_BDADDR_LEN  18

#define UINT8 	uint8_t
#define UINT16 	uint16_t
#define UINT32 	uint32_t
#define INT8 	int8_t
#define INT16 	int16_t
#define INT32 	int32_t
#define CHAR 	char
#define BOOLEAN bool 

typedef enum
{
    AG_GATTS_REGISTER_SERVER = 0,
    AG_GATTS_CONNECT,
    AG_GATTS_DISCONNECT,
    AG_GATTS_GET_RSSI_DONE,

    AG_GATTS_EVENT_MAX
}AG_GATTS_EVENT_T;

/** GATT ID adding instance id tracking to the UUID */
typedef struct
{
    CHAR  uuid[AG_GATT_MAX_UUID_LEN];
    UINT8 inst_id;
} AG_GATT_ID_T;

/** GATT Service ID also identifies the service type (primary/secondary) */
typedef struct
{
    AG_GATT_ID_T    id;
    UINT8 is_primary;
} AG_GATTS_SRVC_ID_T;
typedef struct
{
    INT32 server_if;
    AG_GATTS_SRVC_ID_T srvc_id;
    INT32 srvc_handle;
} AG_GATTS_ADD_SRVC_RST_T;

typedef struct
{
    INT32 server_if;
    CHAR uuid[AG_GATT_MAX_UUID_LEN];
    INT32 srvc_handle;
    INT32 char_handle;
} AG_GATTS_ADD_CHAR_RST_T ;

typedef struct
{
    INT32 server_if;
    CHAR uuid[AG_GATT_MAX_UUID_LEN];
    INT32 srvc_handle;
    INT32 descr_handle;
} AG_GATTS_ADD_DESCR_RST_T;

typedef struct
{
    INT32 conn_id;
    INT32 trans_id;
    CHAR btaddr[AG_MAX_BDADDR_LEN];
    INT32 attr_handle;
    INT32 offset;
    INT32 length;
    UINT8 need_rsp;
    UINT8 is_prep;
    UINT8 value[AG_GATT_MAX_ATTR_LEN];
} AG_GATTS_REQ_WRITE_RST_T;

typedef struct
{
    INT32 conn_id;
    INT32 trans_id;
    CHAR btaddr[AG_MAX_BDADDR_LEN];
    INT32 attr_handle;
    INT32 offset;
    UINT8 is_long;
} AG_GATTS_REQ_READ_RST_T;

typedef void (*fp_onGattsInitCallback)(INT32 serverIf);
typedef void (*fp_onGattsAddServiceCallback)(AG_GATTS_ADD_SRVC_RST_T * bt_gatts_add_srvc);
typedef void (*fp_onGattsAddCharCallback)(AG_GATTS_ADD_CHAR_RST_T *bt_gatts_add_char );
typedef void (*fp_onGattsAddDescCallback)(AG_GATTS_ADD_DESCR_RST_T *bt_gatts_add_desc);
typedef void (*fp_onGattsReqWrite)(AG_GATTS_REQ_WRITE_RST_T *bt_gatts_req_write);
typedef void (*fp_onGattsReqRead)(AG_GATTS_REQ_READ_RST_T *bt_gatts_req_read);
typedef void (*fp_onGattsConnectionEventCallback)(AG_GATTS_EVENT_T bt_gatts_connection_evt);
typedef void (*fp_onGattsStartServerCallback)();
typedef void (*fp_onGattsStopServerCallback)();
typedef void (*fp_onGattsDeleteServerCallback)();

typedef struct _IAGGattServerCallback
{
	fp_onGattsInitCallback onGattsInitCallback;
	fp_onGattsAddServiceCallback onGattsAddServiceCallback;
	fp_onGattsAddCharCallback onGattsAddCharCallback;
	fp_onGattsAddDescCallback onGattsAddDescCallback;
	fp_onGattsReqWrite onGattsReqWrite;
	fp_onGattsReqRead onGattsReqRead;
	fp_onGattsConnectionEventCallback onGattsConnectionEventCallback;
	fp_onGattsStartServerCallback onGattsStartServerCallback;
	fp_onGattsStopServerCallback onGattsStopServerCallback;
	fp_onGattsDeleteServerCallback onGattsDeleteServerCallback;
}IAGGattServerCallback;

// start a thread
INT32 CSM_init() ;
// quit the thread
INT32 CSM_deinitGatts() ;
// setcb
void CSM_setCallback(IAGGattServerCallback* callback) ;
// getcb
IAGGattServerCallback* CSM_getCallback() ;

INT32 CSM_addService(INT32 server_if, CHAR * service_uuid, UINT8 is_primary, INT32 number) ;

INT32 CSM_addChar(INT32 server_if, INT32 service_handle, CHAR * uuid, INT32 properties, INT32 permissions) ;

INT32 CSM_addDesc(INT32 server_if, INT32 service_handle, CHAR * uuid, INT32 permissions) ;

INT32 CSM_startService(INT32 server_if, INT32 service_handle, INT32 transport) ;

INT32 CSM_stopService(INT32 server_if, INT32 service_handle) ;

INT32 CSM_deleteService(INT32 server_if, INT32 service_handle) ;

INT32 CSM_unregisterService(INT32 server_if) ;

INT32 CSM_sendResponse(INT32 conn_id,INT32 trans_id,INT32 status,INT32 handle,CHAR * p_value,INT32 value_len,INT32 auth_req) ;

INT32 CSM_sendIndication(INT32 server_if, INT32 handle, INT32 conn_id, INT32 fg_confirm, CHAR * p_value, INT32 value_len) ;

void CSM_setServerIf(INT32 serverIf);

void CSM_delServerIf(INT32 serverIf);

INT32 enableAdv(BOOLEAN enable);

INT32 setAdvData();
#ifdef __cplusplus
}
#endif

#endif //AG_GATT_API_H
