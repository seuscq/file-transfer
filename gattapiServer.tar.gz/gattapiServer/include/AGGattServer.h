/********************************************************************************************
*Copyright(C) Alibaba.inc
*Author:    qingjiang.xqj@alibaba-inc.com
*Description:  gatt server interface
*********************************************************************************************/
#ifndef AG_GATT_SERVER_H
#define AG_GATT_SERVER_H
#include "AGDefine.h"
#ifdef __cplusplus
extern "C" {
#endif

#define AG_GATT_MAX_ATTR_LEN 600
#define AG_GATT_MAX_UUID_LEN 37
#define AG_MAX_BDADDR_LEN  18

typedef enum
{
    AG_GATTS_REGISTER_SERVER = 0,
    AG_GATTS_CONNECT,
    AG_GATTS_DISCONNECT,
    AG_GATTS_GET_RSSI_DONE,

    AG_GATTS_EVENT_MAX
}AG_GATTS_EVENT_T;

/** GATT ID adding instance id tracking to the UUID */
typedef struct
{
    CHAR  uuid[AG_GATT_MAX_UUID_LEN];
    UINT8 inst_id;
} AG_GATT_ID_T;

/** GATT Service ID also identifies the service type (primary/secondary) */
typedef struct
{
    AG_GATT_ID_T    id;
    UINT8 is_primary;
} AG_GATTS_SRVC_ID_T;
typedef struct
{
    INT32 server_if;
    AG_GATTS_SRVC_ID_T srvc_id;
    INT32 srvc_handle;
} AG_GATTS_ADD_SRVC_RST_T;

typedef struct
{
    INT32 server_if;
    CHAR uuid[AG_GATT_MAX_UUID_LEN];
    INT32 srvc_handle;
    INT32 char_handle;
} AG_GATTS_ADD_CHAR_RST_T ;

typedef struct
{
    INT32 server_if;
    CHAR uuid[AG_GATT_MAX_UUID_LEN];
    INT32 srvc_handle;
    INT32 descr_handle;
} AG_GATTS_ADD_DESCR_RST_T;

typedef struct
{
    INT32 conn_id;
    INT32 trans_id;
    CHAR btaddr[AG_MAX_BDADDR_LEN];
    INT32 attr_handle;
    INT32 offset;
    INT32 length;
    UINT8 need_rsp;
    UINT8 is_prep;
    UINT8 value[AG_GATT_MAX_ATTR_LEN];
} AG_GATTS_REQ_WRITE_RST_T;

typedef struct
{
    INT32 conn_id;
    INT32 trans_id;
    CHAR btaddr[AG_MAX_BDADDR_LEN];
    INT32 attr_handle;
    INT32 offset;
    UINT8 is_long;
} AG_GATTS_REQ_READ_RST_T;



class IAGGattServerCallback
{
public:

    virtual void onGattsInitCallback(INT32 serverIf) = 0;

    virtual void onGattsAddServiceCallback(AG_GATTS_ADD_SRVC_RST_T * bt_gatts_add_srvc  ) = 0;

    virtual void onGattsAddCharCallback(AG_GATTS_ADD_CHAR_RST_T *bt_gatts_add_char ) = 0;

    virtual void onGattsAddDescCallback(AG_GATTS_ADD_DESCR_RST_T *bt_gatts_add_desc) = 0;

    virtual void onGattsReqWrite(AG_GATTS_REQ_WRITE_RST_T *bt_gatts_req_write) = 0;

    virtual void onGattsReqRead(AG_GATTS_REQ_READ_RST_T *bt_gatts_req_read) = 0;

    virtual void onGattsConnectionEventCallback(AG_GATTS_EVENT_T bt_gatts_connection_evt) = 0;

    virtual void onGattsStartServerCallback() = 0;

    virtual void onGattsStopServerCallback() = 0;

    virtual void onGattsDeleteServerCallback() = 0;
};

class AGGattServer
{
public:
    //GATT server

    virtual INT32 init() = 0;

    virtual INT32 deinitGatts() = 0;

    virtual void setCallback(IAGGattServerCallback* callback) = 0;

    //virtual IAGGattServerCallback* getCallback() = 0;

    virtual INT32 addService(INT32 server_if, CHAR * service_uuid, UINT8 is_primary, INT32 number) = 0;

    virtual INT32 addChar(INT32 server_if, INT32 service_handle, CHAR * uuid, INT32 properties, INT32 permissions) = 0;

    virtual INT32 addDesc(INT32 server_if, INT32 service_handle, CHAR * uuid, INT32 permissions) = 0;

    virtual INT32 startService(INT32 server_if, INT32 service_handle, INT32 transport) = 0;

    virtual INT32 stopService(INT32 server_if, INT32 service_handle) = 0;

    virtual INT32 deleteService(INT32 server_if, INT32 service_handle) = 0;

    virtual INT32 unregisterService(INT32 server_if) = 0;

    virtual INT32 sendResponse(INT32 conn_id,INT32 trans_id,INT32 status,INT32 handle,CHAR * p_value,INT32 value_len,INT32 auth_req) = 0;

    virtual INT32 sendIndication(INT32 server_if, INT32 handle, INT32 conn_id, INT32 fg_confirm, CHAR * p_value, INT32 value_len) = 0;

    virtual ~AGGattServer(){}

};


#ifdef __cplusplus
}
#endif
#endif //AG_GATT_SERVER_H