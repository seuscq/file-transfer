cp ../../bluez-5.50/src/.libs/libshared-mainloop.a lib/
