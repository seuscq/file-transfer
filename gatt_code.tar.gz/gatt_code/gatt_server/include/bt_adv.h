#ifndef BT_ADV_H
#define BT_ADV_H

#ifdef __cplusplus
extern "C" {
#endif
#include <stdbool.h>
int enableAdv(bool enable);
int setAdvData();

#ifdef __cplusplus
}
#endif

#endif //AG_GATT_API_H
